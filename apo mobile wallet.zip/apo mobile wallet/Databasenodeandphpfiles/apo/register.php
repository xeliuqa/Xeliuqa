<?php 
$response = array(); 
include 'db_connect.php'; 
include 'functions.php'; //Get the input request parameters 
$inputJSON = file_get_contents('php://input'); 
$input = json_decode($inputJSON, TRUE); 
//convert JSON into array
 
//Check for Mandatory parameters 
if(isset($input['email']) && isset($input['password']) && isset($input['name']) && isset($input['address']) && isset($input['secret'])){
	$email = $input['email'];
	$password = $input['password'];
	$name = $input['name'];
	$address = $input['address'];
	$key = $input['secret'];
	$addressb = $input['addressb'];
	$keyb = $input['secretb'];
        $word = $input['code'];
	$hashes = md5( rand(0,1000) );
	
	$dt = new DateTime();
        $time = $dt->format('Y-m-d H:i:s');
	//Check if user already exist
	if(!userExists($name)){
 
        $hash = dec_enc(encrypt, $password);
		//Get a unique Salt
		$salt = getSalt();
		
		//Generate a unique password Hash
		$passwordHash = password_hash(concatPasswordWithSalt($password,$salt),PASSWORD_DEFAULT);
		
		
		//Query to register new user
		$insertQuery = "INSERT INTO users(email, username, password, salt, eth_address, eth_secret, hash, btc_address, btc_secret, hashes) VALUES (?,?,?,?,?,?,?,?,?,?)";
		if($stmt = $con->prepare($insertQuery)){
			$stmt->bind_param("ssssssssss",$email,$name,$passwordHash,$salt,$address,$key,$hash,$addressb,$keyb,$hashes);
			$stmt->execute();
			$response["status"] = 0;
			$response["message"] = "User created";
			$stmt->close();
			
		//Send Email
			$to = $username;
            $subject = 'AFRICUNIA BANK WALLET';
            $message = 'Welcome to AFRICUNIA BANK!' . "\r\n" . "\r\n" .
                            'Click the button below to complete your verification for AFCASH Android Mobile Multicurrency Wallet:' . "\r\n" . "\r\n" .
                            'CLICK HERE TO VERIFY EMAIL' . "\r\n" .
                            'http://ifastbit.com/mobile/verify.php?hash='. $hashes . "\r\n" . "\r\n" .
                            '3 Security Tips:' . "\r\n" .
                            '* DO NOT give your password to anyone!' . "\r\n" .
                            '* DO NOT call any phone number for someone claiming to be AFRICUNIA Support!' . "\r\n" .
                            '* DO NOT send any money to anyone claiming to be a member of AFRICUNIA!' . "\r\n" . "\r\n" .
                            'If this activity is not your own operation, please contact us immediately on info@africunia.com.' . "\r\n" . "\r\n".
                           'AFRICUNIA BANK Team' . "\r\n" . "\r\n" .
                           'Automated message. Please do not reply!' . "\r\n" ."\r\n" .
                           '';
            $headers = 'From: noreply-africunia <info@africunia.com>' . "\r\n" .
                           'Reply-To: info@africunia.com' . "\r\n" .
                           'X-Mailer: PHP/' . phpversion();
            mail($to, $subject, $message, $headers);
		}
	}
	else{
		$response["status"] = 1;
		$response["message"] = "User exists";
	}
}
else{
	$response["status"] = 2;
	$response["message"] = "Missing mandatory parameters";
}
echo json_encode($response);
?>
