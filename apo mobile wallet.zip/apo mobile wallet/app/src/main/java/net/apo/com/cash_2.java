package net.apo.com;
import android.widget.ImageView;

public class cash_2 {
    public String timeStamp;
    public String from;
    public String amount;
    public String status;
}
