package net.apo.com;

public class List_Data {
    public Integer image;
    public String name;
    public String amount;

}
