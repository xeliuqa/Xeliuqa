package net.apo.com;

public class cash_ {
    public Integer timeStamp;
    public String from;
    public String amount;
    public String hash;
}
