package net.apo.com;

public class Config {

    public static String url() {
        String urls="51.195.201.9"; //Enter your server ip
        return urls;
    }
    public static String key() {
        String keys = ""; //Enter your license key
        return keys;
    }
    public static String pass() {
        String passs = ""; //Enter your license pass
        return passs;
    }
    public static String code() {
        String codes = ""; // Enter your code for server connection
        return codes;
    }
    public static String smartcontract() {
        String smartcontracts = "";//Smart contract of your ERC20 token
        return smartcontracts;
    }
    public static String ethplorerAPI() {
        String api = "EK-jFNSf-9LPTQoq-S1CmY";//contact https://ethplorer.io/ for this API
        return api;
    }
    public static String privacy() {
        String pr=""; //Enter link privacy
        return pr;
    }
    public static String terms() {
        String ter=""; //Enter terms and condition
        return ter;
    }
}
