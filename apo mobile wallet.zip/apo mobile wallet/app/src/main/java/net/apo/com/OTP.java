package net.apo.com;

public class OTP {
}
